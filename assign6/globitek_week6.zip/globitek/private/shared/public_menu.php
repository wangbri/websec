<div id="menu">
  <ul>
    <li><a href="<?php echo url_for('/index.php'); ?>">Home</a></li>
    <li><a href="<?php echo url_for('/territories.php'); ?>">Find a Salesperson</a></li>
    <li><a href="<?php echo url_for('/staff/index.php'); ?>">Staff Area</a></li>
  </ul>
</div>
