<div id="menu">
  <ul>
    <li><a href="<?php echo url_for('/index.php'); ?>">Public Site</a></li>
    <li><a href="<?php echo url_for('/staff/index.php'); ?>">Staff Menu</a></li>
    <li><a href="<?php echo url_for('/staff/logout.php'); ?>" style="color: red;">Log out</a></li>
  </ul>
</div>
