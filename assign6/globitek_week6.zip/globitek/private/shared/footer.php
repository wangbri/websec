  </body>
</html>

<?php if(isset($db)) { db_close($db); } ?>
