<?php
require_once('../../../private/initialize.php');
require_login();
?>
<?php redirect_to('../index.php'); ?>
